
RAI2Screwdriver - v1 2022-03-30 4:13pm
==============================

This dataset was exported via roboflow.ai on March 30, 2022 at 9:15 AM GMT

It includes 23 images.
Screwdrivers are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically


